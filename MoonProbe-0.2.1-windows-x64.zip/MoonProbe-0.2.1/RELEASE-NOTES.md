# MoonProbe 0.2.1：真实进程接入试验

本版本增加 Windows 本地 JSON 工具进程适配器，核心逻辑仍由 MoonBit 执行。源码提交 da358f2841db20c46db8cb18615be174bf62f0cc。

实际案例使用 Python 标准库 urllib.parse：消费方要求保留空字符串，而 parse_qs 默认丢弃空值。32 个生成用例发现 3 个同签名输出契约失败，反例从 153 字节缩到 12 字节的 {"value":""}。使用正常的 keep_blank_values 配置后，全部历史语料与新生成的 32 个用例通过。它是实际接入配置与消费契约不匹配，不是 Python 上游缺陷，也不是已有真实用户产品的故障。

过程与边界见 docs/real-tool-case.md。evidence/process-case 包含原始命令、报告、语料、回放及独立语义样本。配置内绝对路径对应验收机器；移动后请重新运行 scripts/verify-process.py 生成配置，不直接复用旧路径。

新增 --process CONFIG 支持 test/replay：本地绝对可执行文件路径、独立参数数组、stdin/stdout JSON、超时和输出限额分类、进程树清理。参数不经过 shell。已有报告在工具调用前即拒绝覆盖。工具可信且继承用户权限；这不是沙箱或 MCP 传输。

本次发布重新执行本地 66 项验收、64 项真实工具/传输检查、1 万组独立差分、12 个成功编译的源码变异与基准，详情由 manifest.json 和原始摘要绑定。干净检出另跑同一组本地验收。不能将本案例视为完整业务语义验证、独立开发者试用或远程 CI 成功记录。

从源码复现：先构建，再使用已有 Python 3.12+ 执行：

    python -B scripts/verify-process.py --out D:/一个尚不存在的证据目录

CLI 本身仍可直接通过 MoonProbe.cmd 或 work/bin/moonprobe.exe 运行，内置 Mock 不需要 Python。完整说明见 README.md。

交付保留源代码、完整 Git 历史、逐文件 SHA-256 和原始验证记录；v0.1、v0.2.0 包保持不变。源码 ZIP 可能规范化换行；运行包保留本次验证的源文件原始字节。

公开仓库、远程 CI、真人复核和录屏、独立开发者试用、真实用户产品案例及赛事提交尚未执行。

项目、可配置缓存和交付物均在 D 盘；原 Word 未修改，未主动写入 C 盘项目文件。应用/系统内部写入未作可验证计量。